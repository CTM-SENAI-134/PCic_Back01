namespace plantaoUC9.Classes
{
    public abstract class Pessoa
    {
        public string? Nome { get; set; }
        public float Rendimento { get; set; }
    }
}